﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lance_Lespinasse_Midterm;
using Lespinasse_Lab5;
using System.Data.SqlClient;

namespace Lespinasse_Lab6

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            btnUpdate.Enabled = false;
            btnUpdate.Visible = false;


            btnDelete.Enabled = false;
            btnDelete.Visible = false;

            //making it so the new buttons aren't seen when the user adds books
        }


        public Form1(int intPersonID)
        {


            InitializeComponent();


            AddPerson.Enabled = false;

            //disabling my add person button when the user is either deleteing or updating data

            PersonV2 temp = new PersonV2();

            SqlDataReader dr = temp.FindOnePerson(intPersonID);




            while (dr.Read())
            {

                //taking the names from the datarender and copying them into the fields

                txtFirstName.Text = dr["FirstName"].ToString();
                txtMiddleName.Text = dr["MiddleName"].ToString();
                txtLastName.Text = dr["LastName"].ToString();
                txtStreet1.Text = dr["Street1"].ToString();
                txtStreet2.Text = dr["Street2"].ToString();
                txtCity.Text = dr["City"].ToString();
                txtState.Text = dr["State"].ToString();
                txtZipCode.Text = dr["ZipCode"].ToString();
                txtPhone.Text = dr["PhoneNumber"].ToString();
                txtCellPhone.Text = dr["CellPhoneNumber"].ToString();
                txtEmail.Text = dr["Email"].ToString();
                txtInstagram.Text = dr["Instagram"].ToString();




                //we added this to store ID in a new label

                lblPersonID.Text = dr["PersonID"].ToString();
            }


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void AddPerson_Click(object sender, EventArgs e)
        {
            //Person temp = new Person();

            PersonV2 temp = new PersonV2();     //insteading of using the Person class we are now using the new PersonV2

            temp.FirstName = txtFirstName.Text;

            temp.MiddleName = txtMiddleName.Text;

            temp.LastName = txtLastName.Text;

            temp.Street1 = txtStreet1.Text;

            temp.Street2 = txtStreet2.Text;

            temp.City = txtCity.Text;

            temp.PhoneNumber = txtPhone.Text;

            temp.ZipCode = txtZipCode.Text;

            temp.Email = txtEmail.Text;

            temp.CellPhoneNumber = txtCellPhone.Text;

            temp.Instagram = txtInstagram.Text;

            temp.State = txtState.Text;             //creating and storing data into the lines of text on our forms. So when the user enters data into the textboxes the program will store what the user enters into a variable

         


            if (!temp.Feedback.Contains("ERROR:"))
            {
                lblfeedback.Text = temp.AddARecord();
                //adding the text to the add a record function
            }

            else
            {
                lblfeedback.Text = temp.Feedback;

            }       //displayting error message

        }

        private void btnDelete_Click(object sender, EventArgs e)        //my delete key press
        {
            Int32 PersonID = Convert.ToInt32(lblPersonID.Text);  //Get the ID from the Label

            //Create a EBook so we can use the delete method
            PersonV2 temp = new PersonV2();

            //Use the EBook ID and pass it to the delete function
            // and get the number of record(s) gets deleted
            lblfeedback.Text = temp.DeleteOnePerson(PersonID);
        }

        private void btnUpdate_Click(object sender, EventArgs e)        //update key press
        {

            PersonV2 temp = new PersonV2();       //copy and pasted over from add person (AKA Add book)

            temp.FirstName = txtFirstName.Text;         //copy and pasted over from add person

            temp.MiddleName = txtMiddleName.Text;

            temp.LastName = txtLastName.Text;

            temp.Street1 = txtStreet1.Text;

            temp.Street2 = txtStreet2.Text;

            temp.City = txtCity.Text;

            temp.PhoneNumber = txtPhone.Text;

            temp.ZipCode = txtZipCode.Text;

            temp.Email = txtEmail.Text;

            temp.CellPhoneNumber = txtCellPhone.Text;

            temp.Instagram = txtInstagram.Text;

            temp.State = txtState.Text;

            temp.PersonID = Convert.ToInt32(lblPersonID.Text);


          
            if (!temp.Feedback.Contains("ERROR:"))
            {
                lblfeedback.Text = temp.UpdateARecord();   //if no errors were found, then perform the insertion into db
            }
            else
            {
                lblfeedback.Text = temp.Feedback;       //if else then error message gets displayed
            }

        }
    }
}
