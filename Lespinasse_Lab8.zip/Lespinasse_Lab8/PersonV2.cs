﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lance_Lespinasse_Midterm;
using System.Data;
using System.Data.SqlClient;

using Lespinasse_Lab6;

namespace Lespinasse_Lab5
{
    class PersonV2: Person //Inheritance from the OG Person class
    {

        //Adding to the new person V2 Class

        private string cellphonenumber;
        private string instagram;
        private int personID;


        public string CellPhoneNumber          //public string which gets Cellphone and returns it
        {
            get
            {
                return cellphonenumber;
            }

            set
            {
                if (ValidationLibrary.NoDash(value) & ValidationLibrary.AllNumbers(value) & ValidationLibrary.PhoneLength(value))
                {

                    cellphonenumber = value;

                }
                else
                {

                    Feedback = "ERROR: Invalid Cell Phone Length OR Dash Included.";

                }
            }
        }


        public string Instagram
        {
            get
            {
                return instagram;
            }

            set
            {
                instagram = value;
            }
        }
        //copy and pasted over from sample 7



        public Int32 PersonID       //creating a new variable
        {
            get
            {
                return personID;
            }

            set
            {
                //if we have the miimum number of pages needed...
                if (value >= 0)
                {
                    personID = value;  //store the # of pages
                }
                else
                {
                    //Store an error msg in Feedback
                    Feedback += "\nERROR: Sorry you entered an invalid Person ID.";
                }
            }
        }

        public string AddARecord()          //my function for adding records to my database
        {
            string strResult = "INSERT INTO PersonV2";      //init string var

            SqlConnection Conn = new SqlConnection();       //connecting an object


            //creating its properites
            Conn.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_LLespinasse;User Id=SE245_LLespinasse;Password=008010258;";        //this is what the db is and where it is



            string strSQL = "INSERT INTO PersonV2 (FirstName, MiddleName, LastName, Street1, Street2, City, State, ZipCode, PhoneNumber, CellPhoneNumber, Email, Instagram) VALUES (@FirstName, @MiddleName, @LastName, @Street1, @Street2, @City, @State, @ZipCode, @PhoneNumber, @CellPhoneNumber, @Email, @Instagram)";


            //spitting out commands

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;          //commander knows what to say
            comm.Connection = Conn;


            //MUST BE MADE IN THE SAME SEQ AS THE SQL
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@MiddleName", MiddleName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@ZipCode", ZipCode);
            comm.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            comm.Parameters.AddWithValue("@CellPhoneNumber", CellPhoneNumber);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Instagram", Instagram);


            //trying to connect to server
            try
            {
                Conn.Open();        //opening the server

                int intRecs = comm.ExecuteNonQuery();
                strResult = $"SUCCESS: Inserted {intRecs} records.";

                Conn.Close();       //closing after sucess


            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;        //if an error accours program tells what error is
            }

            finally
            {

            }


            //returning the feedback string
            return strResult;
        }

        public string ConnectRecord()
        {
            //this will be testing to make sure my file can connec to the db

            string StrResult = "";

            SqlConnection Conn = new SqlConnection();

            Conn.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_LLespinasse;User Id=SE245_LLespinasse;Password=008010258;";        //this is what the db is and where it is



            try
            {
                Conn.Open();

                StrResult = "SUCCESS";//making sure it connects and if it does display it to me and then close the connection afterwards
                Conn.Close();
            }

            catch (Exception err)
            {
                StrResult = "Error:" + err.Message;

            }


            finally
            {

            }

            return StrResult;


        }


        //creating a function that searches and displays the person I am curretly looking for


        public DataSet SearchPerson(String strFirstName, String strLastName) //seaerching through my person db
        {
            DataSet ds = new DataSet();     //creating a dataset to return filled

            SqlCommand comm = new SqlCommand();     //command for the sql statement


            String strSQL = "SELECT PersonID, FirstName, LastName, Street1 FROM PersonV2 WHERE 0=0";

            if (strFirstName.Length > 0)
            {
                strSQL += " AND FirstName LIKE @FirstName";
                comm.Parameters.AddWithValue("@FirstName", "%" + strFirstName + "%");           //copy and pasted over changing and switching up my variables to make sure program searches for the first and last name
            }
            if (strLastName.Length > 0)
            {
                strSQL += " AND LastName LIKE @LastName";
                comm.Parameters.AddWithValue("@LastName", "%" + strLastName + "%");


            }



            SqlConnection conn = new SqlConnection();

            string strConn = @GetConnected();       //creating the who what and where of my database

            conn.ConnectionString = strConn;

            comm.Connection = conn;     //tell the commander what to use
            comm.CommandText = strSQL;      //telling the command what to say

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;



            //grabbing data
            conn.Open();
            da.Fill(ds, "PersonV2_Temp");
            conn.Close();

            return ds;
        }



        //function that finds the person 
        public SqlDataReader FindOnePerson(int intPersonID)
        {

            //creating the tools I need for the database

            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            //the connection string

            string strConn = GetConnected();


            //my SQL command String to pull up one person data

            string sqlString = "SELECT * FROM PersonV2 WHERE PersonID = @PersonID";

            conn.ConnectionString = strConn;        //telling connection who want where and how

            comm.Connection = conn;     //giving the command object the information it needs

            comm.CommandText = sqlString;

            comm.Parameters.AddWithValue("@PersonID", intPersonID);

            //opening my database



            conn.Open();

            //leaving it open and returning feedback

            return comm.ExecuteReader();
        }



        private string GetConnected()

            //my login for sql
        {
            return @"Server=sql.neit.edu\sqlstudentserver,4500;Database=SE245_LLespinasse;User Id=SE245_LLespinasse;Password=008010258;";
        }



        //creating my delete person function


        public string DeleteOnePerson(int intPersonID)      //deleteing an Person
        {

            Int32 intRecords = 0;
            string strResult = "";

            //Create and Initialize the DB Tools that we need
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();


            //my sql login
            string strConn = GetConnected();

            //My SQL command string to pull up one person's data
            string sqlString =
           "DELETE FROM PersonV2 WHERE PersonID = @PersonID;";

            //Tell the connection object the who, what, where, how
            conn.ConnectionString = strConn;

            comm.Connection = conn;         //giving the command the infomartion it needs
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@PersonID", intPersonID);


            try
            {

                conn.Open();    //opening the connection

                intRecords = comm.ExecuteNonQuery();

                strResult = intRecords.ToString() + " Records Deleted:";       //running the delete and telling me if it was deleted
            }

            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;      //Set feedback to state there was an error & error info
            }

            finally
            {
                conn.Close();
            }

            return strResult;

        }





        //creating my update a person function



        public string UpdateARecord()       //updating a record
        {
            Int32 intRecords = 0;
            string strResult = "";

            //the sql string
            string strSQL = "UPDATE PersonV2 SET FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName, Street1=@Street1, Street2=@Street2, City=@City, State=@State, ZipCode=@ZipCode, PhoneNumber=@PhoneNumber, CellPhoneNumber=@CellPhoneNumber, Email=@Email, Instagram=@Instagram  WHERE PersonID = @PersonID;";

            // Create a connection to DB
            SqlConnection conn = new SqlConnection();
            //Create the who, what where of the DB
            string strConn = GetConnected();
            conn.ConnectionString = strConn;

            // prints out the comamnd
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;  //Commander knows what to say
            comm.Connection = conn;     //Where's the phone?  Here it is

            //Fill in the paramters (Has to be created in same sequence as they are used in SQL Statement) copy from other usage
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@MiddleName", MiddleName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@ZipCode", ZipCode);
            comm.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            comm.Parameters.AddWithValue("@CellPhoneNumber", CellPhoneNumber);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Instagram", Instagram);
            comm.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                //Open the connection
                conn.Open();

                //Run the Update and store the number of records effected
                intRecords = comm.ExecuteNonQuery();
                strResult = intRecords.ToString() + " Records Updated.";
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;                //Set feedback to state there was an error & error info
            }
            finally
            {
                //close the connection
                conn.Close();
            }

            return strResult;

        }








    }
}
