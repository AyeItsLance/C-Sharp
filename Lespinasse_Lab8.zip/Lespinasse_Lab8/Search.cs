﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lespinasse_Lab6;

namespace Lespinasse_Lab5
{
    public partial class Search : Form      //copied over for accture results minor chages to search for specifc person
    {
        public Search()
        {
            InitializeComponent();
        }

        private void dgvResults_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvResults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            string strPersonID = dgvResults.Rows[e.RowIndex].Cells[0].Value.ToString();     //getting my data

            //displaying the message that pops up


            MessageBox.Show(strPersonID);

            //converting and strings into ints


            int intPersonID = Convert.ToInt32(strPersonID);

            //creating the new editior and passint it to Person id


            Form1 Editor = new Form1(intPersonID);
            Editor.ShowDialog();

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //getting my data
            PersonV2 temp = new PersonV2();


            //this preforms our search that we made and returns our data

            DataSet ds = temp.SearchPerson(txtFirstName.Text, txtLastName.Text);

            dgvResults.DataSource = ds;                                  //point datagrid to dataset
            dgvResults.DataMember = ds.Tables["PersonV2_Temp"].ToString();     // What table in the dataset?        

        }
    }
}
