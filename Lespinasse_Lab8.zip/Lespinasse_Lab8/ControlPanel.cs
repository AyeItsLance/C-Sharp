﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lespinasse_Lab6;

namespace Lespinasse_Lab5
{
    public partial class ControlPanel : Form
    {
        public ControlPanel()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {

            Form1 temp = new Form1();

            temp.Show();


        }

        private void SearchPerson_Click(object sender, EventArgs e)
        {

            Search temp = new Search();         //displaying my search window

            temp.Show();

        }
    }
}
