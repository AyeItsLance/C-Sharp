﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lance_Lespinasse_Midterm
{
    class Person
    {
              //creating my class for person Everything will be private
       
            private string fName;
            private string mName;
            private string lName;
            private string street1;
            private string street2;
            private string city;
            private string state;
            private string zipCode;
            private string phonenumber;
            private string email;
            private string feedback = "";


        public string FirstName         //public string which gets fName and returns it
            {
                get
                {
                    return fName;
                }

                set
                {
                    fName = value;
                }
            }

            public string MiddleName          //public string which gets Midle name and returns it
            {
                get
                {
                    return mName;
                }

                set
                {
                    mName = value;
                }
            }



            public string LastName          //public string which gets lName and returns it
            {
                get
                {
                    return lName;
                }

                set
                {
                    lName = value;
                }
            }



            public string Street1          //public string which gets the firts street and returns it
            {
                get
                {
                    return street1;
                }

                set
                {
                    street1 = value;
                }
            }



            public string Street2          //public string which gets street 2 and returns it
            {
                get
                {
                    return street2;
                }

                set
                {
                    street2 = value;
                }
            }

            public string City          //public string which gets City and returns it
            {
                get
                {
                    return city;
                }

                set
                {
                    city = value;
                }
            }


            public string State          //public string which gets State and returns it
            {
                get
                {
                    return state;
                }

                set
                {
                    if (ValidationLibrary.StateLength(value) & ValidationLibrary.AllLetters(value))
                    {

                        state = value;

                    }

                    else
                    {
                        Feedback = "ERROR: Invalid State Length:";
                    }
                }
            }

            public string ZipCode          //public string which gets ZipCode and returns it
            {
                get
                {
                    return zipCode;
                }

                set
                {
                    if (ValidationLibrary.ZipLength(value) & ValidationLibrary.AllNumbers(value))
                    {

                    zipCode = value;
                    
                    }

                    else
                    {

                    Feedback = "ERROR: Invalid Zip Length.";
                    
                    }
                }
            }

            public string PhoneNumber          //public string which gets Phone # and returns it
            {
                get
                {
                    return phonenumber;
                }

                set
                {
                    if (ValidationLibrary.NoDash(value) & ValidationLibrary.AllNumbers(value) & ValidationLibrary.PhoneLength(value))
                    {

                        phonenumber = value;
                    
                    }    
                    else
                    {

                    Feedback = "ERROR: Invalid Phone Length OR Dash Included.";

                    }
                }
            }


            public string Email          //public string which gets Email and returns it
            {
                get
                {
                    return email;
                }

                set
                {
                    if (ValidationLibrary.IsValidEmail(value) & ValidationLibrary.PeriodNeeded(value))
                    {

                        email = value;
                
                    }

                    else
                    {

                        Feedback = "ERROR: Invalid Email Format.";
                
                    }
                }
            }


            public string Feedback
            {

                get
                {
                    return feedback;
                }

                set
                {
                    feedback = value;
                }


            }



    }
}
