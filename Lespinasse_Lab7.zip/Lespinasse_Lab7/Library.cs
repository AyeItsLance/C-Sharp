﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lance_Lespinasse_Midterm
{


    class ValidationLibrary     //my val library COPY AND PASTED
    {

        public static bool IsFitFilledIn(string temp, int minlen)
        {
            bool result = false;

            if (temp.Length >= minlen)
            {
                result = true;
            }
            return result;
        }

        public static bool PhoneLength(string temp)             //created my new validation  for phone length but couldn't make it work ask scott!!!! UPDATE: GOT IT WORKING JUST WEIRD
        {
            bool blnResult = false;

            if (temp.Length == 10)
            {

                blnResult = true;

            }

            return blnResult;

        }


        public static bool ZipLength(string temp)       //zip length making sure its 5
        {

            bool blnResult = true;

            if (temp.Length != 5)
            {

                blnResult = false;

            }

            return blnResult;

        }




        public static bool StateLength(string temp)         //state length making sure its 2
        {

            bool blnResult = true;

            if (temp.Length != 2)
            {

                blnResult = false;

            }

            return blnResult;

        }


        public static bool IsValidEmail(string temp)        //making sure user enters valid email
        {
            bool blnResult = true;

            int atLocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atLocation + 1);



            int periodLocation = temp.LastIndexOf(".");

            if (temp.Length < 8)
            {
                blnResult = false;
            }


            else if (atLocation < 2)

            {
                blnResult = false;
            }

            else if (periodLocation + 2 > (temp.Length))
            {
                blnResult = false;
            }

            return blnResult;
        }




        public static bool IsAFutureDate(DateTime temp)     //making sure the user selects future date
        {
            bool blnResult;

            if (temp <= DateTime.Now)
            {
                blnResult = false;
            }

            else
            {
                blnResult = true;
            }

            return blnResult;
        }

        public static bool IsMinimumAmount(int temp, int min)
        {
            bool blnResult;

            if (temp >= min)
            {
                blnResult = true;
            }

            else
            {
                blnResult = false;
            }

            return blnResult;

        }



        public static bool IsMinimumAmount(double temp, double min)
        {
            bool blnResult;

            if (temp >= min)
            {
                blnResult = true;
            }

            else
            {
                blnResult = false;
            }

            return blnResult;

        }

        public static bool AllLetters(string temp)      //Making sure ONLY enters in letters
        {
            bool result = true;

            string strGoodChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            foreach (char ch in temp.ToUpper())
            {
                if (!strGoodChars.Contains(ch))
                {
                    result = false;
                    break;
                }
            }

            return result;
        }


        public static bool AllNumbers(string temp)  //Making sure ONLY enters in numbers
        {
            bool result = true;

            string strGoodChars = "0123456789";

            foreach (char ch in temp.ToUpper())
            {
                if (!strGoodChars.Contains(ch))
                {
                    result = false;
                    break;
                }
            }

            return result;
        }


        public static bool PeriodNeeded(string temp)//forcing user to enter a period
        {
            bool result = true;

            if (!temp.Contains("."))
            {
                result = true;
            }

            

            return result;
        }

        public static bool NoDash(string temp)//had werid error during testing when typing dashes into sql ASK SCOTT
        {
            bool result = true;

            if (temp.Contains("-"))
            {
                result = true;
            }



            return result;
        }

    }

}
