﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lance_Lespinasse_Midterm;
using Lespinasse_Lab5;

namespace Lespinasse_Lab6

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void AddPerson_Click(object sender, EventArgs e)
        {
            //Person temp = new Person();

            PersonV2 temp = new PersonV2();     //insteading of using the Person class we are now using the new PersonV2

            temp.FirstName = txtFirstName.Text;

            temp.MiddleName = txtMiddleName.Text;

            temp.LastName = txtLastName.Text;

            temp.Street1 = txtStreet1.Text;

            temp.Street2 = txtStreet2.Text;

            temp.City = txtCity.Text;

            temp.PhoneNumber = txtPhone.Text;

            temp.ZipCode = txtZipCode.Text;

            temp.Email = txtEmail.Text;

            temp.CellPhoneNumber = txtCellPhone.Text;

            temp.Instagram = txtInstagram.Text;

            temp.State = txtState.Text;             //creating and storing data into the lines of text on our forms. So when the user enters data into the textboxes the program will store what the user enters into a variable

         


            if (!temp.Feedback.Contains("ERROR:"))
            {
                lblfeedback.Text = temp.AddARecord();
                //adding the text to the add a record function
            }

            else
            {
                lblfeedback.Text = temp.Feedback;

            }       //displayting error message

        }
    }
}
