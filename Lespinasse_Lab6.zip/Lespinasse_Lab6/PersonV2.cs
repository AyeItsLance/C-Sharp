﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lance_Lespinasse_Midterm;
using System.Data;
using System.Data.SqlClient;

namespace Lespinasse_Lab5
{
    class PersonV2: Person //Inheritance from the OG Person class
    {

        //Adding to the new person V2 Class

        private string cellphonenumber;
        private string instagram;


        public string CellPhoneNumber          //public string which gets Cellphone and returns it
        {
            get
            {
                return cellphonenumber;
            }

            set
            {
                if (ValidationLibrary.NoDash(value) & ValidationLibrary.AllNumbers(value) & ValidationLibrary.PhoneLength(value))
                {

                    cellphonenumber = value;

                }
                else
                {

                    Feedback = "ERROR: Invalid Cell Phone Length OR Dash Included.";

                }
            }
        }


        public string Instagram
        {
            get
            {
                return instagram;
            }

            set
            {
                instagram = value;
            }
        }
            //copy and pasted over from sample 7

        public string AddARecord()          //my function for adding records to my database
        {
            string strResult = "INSERT INTO PersonV2";      //init string var

            SqlConnection Conn = new SqlConnection();       //connecting an object


            //creating its properites
            Conn.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_LLespinasse;User Id=SE245_LLespinasse;Password=008010258;";        //this is what the db is and where it is



            string strSQL = "INSERT INTO PersonV2 (FirstName, MiddleName, LastName, Street1, Street2, City, State, ZipCode, PhoneNumber, CellPhoneNumber, Email, Instagram) VALUES (@FirstName, @MiddleName, @LastName, @Street1, @Street2, @City, @State, @ZipCode, @PhoneNumber, @CellPhoneNumber, @Email, @Instagram)";


            //spitting out commands

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;          //commander knows what to say
            comm.Connection = Conn;


            //MUST BE MADE IN THE SAME SEQ AS THE SQL
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@MiddleName", MiddleName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@ZipCode", ZipCode);
            comm.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            comm.Parameters.AddWithValue("@CellPhoneNumber", CellPhoneNumber);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Instagram", Instagram);


            //trying to connect to server
            try
            {
                Conn.Open();        //opening the server

                int intRecs = comm.ExecuteNonQuery();
                strResult = $"SUCCESS: Inserted {intRecs} records.";

                Conn.Close();       //closing after sucess


            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;        //if an error accours program tells what error is
            }

            finally
            {

            }


            //returning the feedback string
            return strResult;
        }

        public string ConnectRecord()
        {
            //this will be testing to make sure my file can connec to the db

            string StrResult = "";

            SqlConnection Conn = new SqlConnection();

            Conn.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_LLespinasse;User Id=SE245_LLespinasse;Password=008010258;";        //this is what the db is and where it is



            try
            {
                Conn.Open();

                StrResult = "SUCCESS";//making sure it connects and if it does display it to me and then close the connection afterwards
                Conn.Close();
            }

            catch (Exception err)
            {
                StrResult = "Error:" + err.Message;

            }


            finally
            {

            }

            return StrResult;


        }




    }
}
