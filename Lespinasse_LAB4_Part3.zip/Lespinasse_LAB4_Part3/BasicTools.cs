﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lespinasse_LAB4_Part3
{
    class BasicTools
    {
        public static void Pause()
        {

            Console.WriteLine("\nPress Any Key to Continue\n");
            Console.ReadKey();

        }
    }
}
