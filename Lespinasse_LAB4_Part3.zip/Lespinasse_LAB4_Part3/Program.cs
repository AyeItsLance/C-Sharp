﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lespinasse_LAB4_Part3
{
    class Program
    {
        public class Person           //creating my class for person Everything will be private
        {
            private string fName;
            private string mName;
            private string lName;
            private string street1;
            private string street2;
            private string city;
            private string state;
            private string zipCode;
            private string phone;
            private string email;
        

            public string FirstName         //public string which gets fName and returns it
            {
                get
                {
                    return fName;
                }

                set
                {
                    fName = value;
                }
            }

            public string MiddleName          //public string which gets Midle name and returns it
            {
                get
                {
                    return mName;
                }

                set
                {
                    mName = value;
                }
            }



            public string LastName          //public string which gets lName and returns it
            {
                get
                {
                    return lName;
                }

                set
                {
                     lName = value;
                }
            }



            public string Street1          //public string which gets the firts street and returns it
            {
                get
                {
                    return street1;
                }

                set
                {
                    street1 = value;
                }
            }



            public string Street2          //public string which gets street 2 and returns it
            {
                get
                {
                    return street2;
                }

                set
                {
                    street2 = value;
                }
            }

            public string City          //public string which gets City and returns it
            {
                get
                {
                    return city;
                }

                set
                {
                    city = value;
                }
            }


            public string State          //public string which gets State and returns it
            {
                get
                {
                    return state;
                }

                set
                {
                    state = value;
                }
            }

            public string ZipCode          //public string which gets ZipCode and returns it
            {
                get
                {
                    return zipCode;
                }

                set
                {
                    zipCode = value;
                }
            }

            public string Phone          //public string which gets Phone # and returns it
            {
                get
                {
                    return phone;
                }

                set
                {
                    phone = value;
                }
            }


            public string Email          //public string which gets Email and returns it
            {
                get
                {
                    return email;
                }

                set
                {
                    email = value;
                }
            }



        }

        static void Main(string[] args)
        {
            string poopy = " Poopy";
            string str;

            //Lance Lespinasse
            // 4/22/2021
            // Lab 4 Part 3 switching to private class


            Console.WriteLine("Hello and Welcome to my Program!!!");
            Person temp = new Person();

            Console.Write("\nPlease Enter Your First Name: ");         //getting the user to enter a first name which will set it to temp fName 
            temp.FirstName = Console.ReadLine();

            Console.Write("\nPlease Enter Your Middle Name: ");         //getting the user to enter a middle name which will set it to temp mName 
            temp.MiddleName = Console.ReadLine();

            Console.Write("\nPlease Enter Your Last Name: ");         //getting the user to enter a Last name which will set it to temp lName 
            temp.LastName = Console.ReadLine();

            Console.Write("\nPlease Enter Your Street Name: ");         //getting the user to enter a street name which will set it to temp street1 
            temp.Street1 = Console.ReadLine();

            Console.Write("\nPlease Enter Your APT Number or if you live in a plaze (IF THIS DOES NOT APPLY TO YOU PLEASE PRESS ENTER TO SKIP): ");         //getting the user to enter a street name which will set it to temp street1 
            temp.Street2 = Console.ReadLine();

            Console.Write("\nPlease Enter Your City Name: ");         //getting the user to enter a city name which will set it to temp city 
            temp.City = Console.ReadLine();

            Console.Write("\nPlease Enter Your State Name: ");         //getting the user to enter a state name which will set it to temp state 
            temp.State = Console.ReadLine();

            Console.Write("\nPlease Enter Your ZipCode Name: ");         //getting the user to enter the zipcode which will set it to temp zipCode 
            temp.ZipCode = Console.ReadLine();

            Console.Write("\nPlease Enter Your Phone Number: ");         //getting the user to enter a phone # which will set it to temp phone 
            temp.Phone = Console.ReadLine();

            Console.Write("\nPlease Enter Your Email: ");         //getting the user to enter a email  which will set it to temp email 
            temp.Email = Console.ReadLine();




            str = string.Concat(temp.FirstName, poopy);     //connecting the fName string with the word "Poopy"

            //displaying to consol
            Console.Write("\nFirst Name: " + (str));
            Console.Write($"\nMiddle Name: {temp.MiddleName}");
            Console.Write($"\nLast Name: {temp.LastName}");
            Console.Write($"\nAddress: {temp.Street1} {temp.Street2} {temp.City} {temp.State} {temp.ZipCode}");
            Console.Write($"\nPhone Number: {temp.Phone}");
            Console.Write($"\nEmail: {temp.Email}");


            BasicTools.Pause();
        }
    }
}
